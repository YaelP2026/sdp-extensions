let params = {};
const statusMap = {
    'list_node.run_native_status.planned': 'planned',
    'list_node.run_native_status.passed': 'passed',
    'list_node.run_native_status.failed': 'failed',
    'list_node.run_native_status.skipped': 'skipped',
    'list_node.run_native_status.blocked': 'blocked',
    'list_node.run_native_status.not_completed': 'inProgress'
};

function parseParams() {
    document.location.search.substring(1).split('&').forEach(addParam);
    document.location.hash.substring(1).split('&').forEach(addParam);
}

function addParam(paramPair) {
    if (!paramPair) return;
    const [name, value] = paramPair.split('=').map(decodeURIComponent);
    params[name] = value;
}

function showSpinner(show, message = 'Generating report, please wait...') {
    const spinner = document.getElementById('spinner');
    spinner.querySelector('.spinner-text').textContent = message;
    spinner.style.display = show ? 'flex' : 'none';
}

function showError(message) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = message;
    errorDiv.style.display = message ? 'block' : 'none';
}

async function fetchAll(entity, query, fields, extraParams = '') {
    const allEntities = [];
    let offset = 0;
    const limit = 1000;
    let hasMore = true;

    const baseUrl = `${params.octane_url}/api/shared_spaces/${params.shared_space}/workspaces/${params.workspace}/${entity}`;

    while (hasMore) {
        const url = `${baseUrl}?fields=${fields}&query="${query}"&limit=${limit}&offset=${offset}${extraParams}`;
        try {
            const response = await fetch(url, {
                headers: {
                    'HPECLIENTTYPE': 'HPE_MQM_UI',
                    'XSRF-HEADER': params.xsrf_token
                },
                credentials: 'include'
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`API Error (${response.status}): ${errorData.description || 'Failed to fetch data'}`);
            }
            const result = await response.json();
            if (result.data && result.data.length > 0) {
                allEntities.push(...result.data);
                hasMore = result.total_count > allEntities.length;
                offset += result.data.length;
            } else {
                hasMore = false;
            }
        } catch (e) {
            console.error(`Failed to fetch from ${url}`, e);
            throw e;
        }
    }
    return allEntities;
}

async function fetchExistingFields(entityType, fieldNames) {
    const url = `${params.octane_url}/api/shared_spaces/${params.shared_space}/workspaces/${params.workspace}/metadata/fields?query="entity_name='${entityType}'"&fields=name&limit=1000`;
    try {
        const response = await fetch(url, {
            headers: { 'HPECLIENTTYPE': 'HPE_MQM_UI', 'XSRF-HEADER': params.xsrf_token },
            credentials: 'include'
        });
        if (!response.ok) return [];
        const result = await response.json();
        const existingNames = new Set((result.data || []).map(f => f.name));
        return fieldNames.filter(f => existingNames.has(f));
    } catch (e) {
        return [];
    }
}

async function generateReport() {
    showSpinner(true);
    showError('');
    document.getElementById('results').innerHTML = '';
    document.getElementById('exportBtn').style.display = 'none';

    try {
        const reqQuery = params.query || '';
        if (!reqQuery || reqQuery === 'null' || reqQuery === 'undefined') {
            throw new Error("No requirements found. The report works on the requirements currently visible in the grid.");
        }
        showSpinner(true, 'Checking available fields...');
        const availableUdfs = await fetchExistingFields('requirement', ['requirement_category_udf', 'requirement_number_udf']);
        const hasCategoryField = availableUdfs.includes('requirement_category_udf');
        const hasNumberField = availableUdfs.includes('requirement_number_udf');

        const reqFields = ['id', 'name'];
        if (hasCategoryField) reqFields.push('requirement_category_udf{name}');
        if (hasNumberField) reqFields.push('requirement_number_udf');

        showSpinner(true, 'Fetching all requirements from the grid...');
        const requirements = await fetchAll('requirements', reqQuery, reqFields.join(','));

        if (requirements.length === 0) {
            showError("No requirements match the current grid filter.");
            showSpinner(false);
            return;
        }

        // Map: reqId -> { id, name, category, reqNumber, tests: [] }
        const reqMap = new Map();
        requirements.forEach(req => {
            const category = hasCategoryField && req.requirement_category_udf && req.requirement_category_udf.name
                ? req.requirement_category_udf.name : '';
            const reqNumber = hasNumberField && req.requirement_number_udf !== undefined && req.requirement_number_udf !== null
                ? req.requirement_number_udf : '';
            reqMap.set(req.id, { id: req.id, name: req.name, category, reqNumber, tests: [] });
        });

        const userTestFilter = document.getElementById('testFilter').value.trim();
        const batchSize = 100;

        for (let i = 0; i < requirements.length; i += batchSize) {
            const batch = requirements.slice(i, i + batchSize);
            const progressMsg = `Processing requirements ${i + 1} to ${Math.min(i + batchSize, requirements.length)} of ${requirements.length}...`;
            showSpinner(true, progressMsg);

            const reqIdFilter = batch.map(r => `covered_requirement={id EQ ${r.id}}`).join('||');

            let combinedTestQuery = `(${reqIdFilter})`;
            if (userTestFilter) {
                combinedTestQuery = `( (${combinedTestQuery}) ; (${userTestFilter}) )`;
            }

            // 1. Fetch tests (with name and application module) covering this batch of requirements
            const testsInBatch = await fetchAll('tests', combinedTestQuery, 'id,name,product_areas{name},covered_requirement{id}');

            if (testsInBatch.length === 0) continue;

            // Build testId -> { name, coveredReqIds, notRun, planned, passed, failed, skipped, blocked, inProgress }
            const testInfoMap = new Map();
            testsInBatch.forEach(test => {
                const coveredReqIds = (test.covered_requirement && test.covered_requirement.data)
                    ? test.covered_requirement.data.map(r => r.id).filter(id => reqMap.has(id))
                    : [];
                const appModule = (test.product_areas && test.product_areas.data && test.product_areas.data.length > 0)
                    ? test.product_areas.data.map(a => a.name).join(', ')
                    : '';
                testInfoMap.set(test.id, {
                    name: test.name, appModule, coveredReqIds,
                    notRun: 0, planned: 0, passed: 0, failed: 0, skipped: 0, blocked: 0, inProgress: 0
                });
            });

            // 2. Fetch last runs for these tests
            const testIdsArray = Array.from(testInfoMap.keys());
            const runsQuery = testIdsArray.map(id => `test={id EQ ${id}}`).join('||');
            const lastRunsQuery = `( (${runsQuery}) ; is_test_last_run EQ true )`;
            const lastRuns = await fetchAll('runs', lastRunsQuery, 'test{id},native_status{logical_name}');

            // 3. Count runs per status for each test
            const testsWithRuns = new Set();
            lastRuns.forEach(run => {
                if (run.test && run.native_status && testInfoMap.has(run.test.id)) {
                    testsWithRuns.add(run.test.id);
                    const statusKey = statusMap[run.native_status.logical_name];
                    if (statusKey) {
                        testInfoMap.get(run.test.id)[statusKey]++;
                    }
                }
            });

            // 4. Tests with no last runs are 'Not Run'
            testInfoMap.forEach((testInfo, testId) => {
                if (!testsWithRuns.has(testId)) {
                    testInfo.notRun = 1;
                }
            });

            // 5. Assign each test to its covered requirements
            testInfoMap.forEach((testInfo, testId) => {
                testInfo.coveredReqIds.forEach(reqId => {
                    reqMap.get(reqId).tests.push({
                        id: testId, name: testInfo.name, appModule: testInfo.appModule,
                        notRun: testInfo.notRun, planned: testInfo.planned, passed: testInfo.passed,
                        failed: testInfo.failed, skipped: testInfo.skipped, blocked: testInfo.blocked,
                        inProgress: testInfo.inProgress
                    });
                });
            });
        }

        // Build flat rows: one per test, or one placeholder row per requirement if no tests
        const rows = [];
        requirements.forEach(req => {
            const reqData = reqMap.get(req.id);
            if (reqData.tests.length === 0) {
                rows.push({ reqId: req.id, reqName: req.name, reqCategory: reqData.category, reqNumber: reqData.reqNumber, testName: '', appModule: '',
                    notRun: 0, planned: 0, passed: 0, failed: 0, skipped: 0, blocked: 0, inProgress: 0 });
            } else {
                reqData.tests.forEach(test => {
                    rows.push({
                        reqId: req.id, reqName: req.name, reqCategory: reqData.category, reqNumber: reqData.reqNumber, testName: test.name, appModule: test.appModule,
                        notRun: test.notRun, planned: test.planned, passed: test.passed,
                        failed: test.failed, skipped: test.skipped, blocked: test.blocked,
                        inProgress: test.inProgress
                    });
                });
            }
        });

        renderTable(rows, hasCategoryField, hasNumberField);
        document.getElementById('exportBtn').style.display = 'inline-block';

    } catch (error) {
        console.error('Error generating report:', error);
        showError(`Failed to generate report: ${error.message}`);
    } finally {
        showSpinner(false);
    }
}

function renderTable(data, hasCategoryField, hasNumberField) {
    const headers = ['Req ID', 'Req Name'];
    const keys = ['reqId', 'reqName'];
    if (hasCategoryField) { headers.push('Req Category'); keys.push('reqCategory'); }
    if (hasNumberField) { headers.push('Req Number'); keys.push('reqNumber'); }
    headers.push('Test Name', 'Application Module', 'Not Run', 'Planned', 'Passed', 'Failed', 'Skipped', 'Blocked', 'In Progress');
    keys.push('testName', 'appModule', 'notRun', 'planned', 'passed', 'failed', 'skipped', 'blocked', 'inProgress');

    let tableHTML = '<table id="reportTable"><thead><tr>';
    headers.forEach(h => tableHTML += `<th>${h}</th>`);
    tableHTML += '</tr></thead><tbody>';

    data.forEach(row => {
        tableHTML += '<tr>';
        keys.forEach(key => {
            const value = row[key] !== null ? row[key] : '';
            tableHTML += `<td>${value}</td>`;
        });
        tableHTML += '</tr>';
    });

    tableHTML += '</tbody></table>';
    document.getElementById('results').innerHTML = tableHTML;
}

function exportToExcel() {
    const table = document.getElementById('reportTable');
    if (!table) {
        showError("No report data to export.");
        return;
    }
    const wb = XLSX.utils.table_to_book(table, { sheet: "Coverage Report" });
    XLSX.writeFile(wb, "RequirementCoverageReport.xlsx");
}

document.addEventListener('DOMContentLoaded', () => {
    parseParams();
    document.getElementById('generateBtn').addEventListener('click', generateReport);
    document.getElementById('exportBtn').addEventListener('click', exportToExcel);
});